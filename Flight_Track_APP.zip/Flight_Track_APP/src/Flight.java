import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Flight extends Thread implements Runnable{
    private String flightNo;
    private String airlines;
    private String aircraftModel;
    private Calendar arrivalTime;
    private Calendar departureTime;
    private ArrayList<String> weekdays;
    private Capital from, to;
    private String status = "Waiting to take off";
    //I want to show popup message so that i create a gui class
    private GUI gui;
    private boolean isLandingTime;

    public Flight(String flightNo, String airlines, String aircraftModel, Calendar arrivalTime, Calendar departureTime, ArrayList<String> weekdays, Capital from, Capital to, GUI gui) {
        this.flightNo = flightNo;
        this.airlines = airlines;
        this.aircraftModel = aircraftModel;
        this.arrivalTime = arrivalTime;
        this.departureTime = departureTime;
        this.weekdays = weekdays;
        this.from = from;
        this.to = to;
        this.gui = gui;
    }

    public String getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }

    public String getAirlines() {
        return airlines;
    }

    public void setAirlines(String airlines) {
        this.airlines = airlines;
    }

    public String getAircraftModel() {
        return aircraftModel;
    }

    public void setAircraftModel(String aircraftModel) {
        this.aircraftModel = aircraftModel;
    }

    public Calendar getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(Calendar arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public Calendar getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(Calendar departureTime) {
        this.departureTime = departureTime;
    }

    public ArrayList<String> getWeekdays() {
        return weekdays;
    }

    public void setWeekdays(ArrayList<String> weekdays) {
        this.weekdays = weekdays;
    }

    public Capital getFrom() {
        return from;
    }

    public void setFrom(Capital from) {
        this.from = from;
    }

    public Capital getTo() {
        return to;
    }

    public void setTo(Capital to) {
        this.to = to;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    //Calendar class returns weekday as an integer but i use it as String so i converted it.
    public boolean isTodayAWeekday(int day){
        if(day == 1){
            if(this.weekdays.contains("Monday")){
                return true;
            }else{
                return false;
            }
        }
        if(day == 2){
            if(this.weekdays.contains("Tuesday")){
                return true;
            }else{
                return false;
            }
        }
        if(day == 3){
            if(this.weekdays.contains("Wednesday")){
                return true;
            }else{
                return false;
            }
        }
        if(day == 4){
            if(this.weekdays.contains("Thursday")){
                return true;
            }else{
                return false;
            }
        }
        if(day == 5){
            if(this.weekdays.contains("Friday")){
                return true;
            }else{
                return false;
            }
        }
        if(day == 6){
            if(this.weekdays.contains("Saturday")){
                return true;
            }else{
                return false;
            }
        }
        if(this.weekdays.contains("Sunday")){
            return true;
        }
        return false;
    }
    
    public boolean isIsLandingTime() {
        return isLandingTime;
    }

    public void setIsLandingTime(boolean isLandingTime) {
        this.isLandingTime = isLandingTime;
    }
    //pass 0 for takeoff 1 for landing, 2 for cancel
    public void writeReportFile(Flight f, int i){
        FileWriter writer = null;
        try {
            writer = new FileWriter("src\\Report.txt", true);
            if(i == 0){
                writer.write(this.airlines + " " + this.aircraftModel + " aircraft with " + this.flightNo + " flight number took off from " + this.from.getName() + " at " + this.departureTime.getTime() + ", for landing in " + this.to.getName() + " at " + this.arrivalTime.getTime() + ".\n");
            }else if(i == 2){
                writer.write(this.airlines + " " + this.aircraftModel + " aircraft with " + this.flightNo + " flight number took off from " + this.from.getName() + " at " + this.departureTime.getTime() + ", for landing in " + this.to.getName() + " at " + this.arrivalTime.getTime() + " cancelled.\n");
            }else{
                writer.write(this.aircraftModel + " aircraft, which belongs to " + this.airlines + " with " + this.flightNo + " flight number, took off from " + this.from.getName() + " at " + this.departureTime.getTime() + " and landed in " + this.to.getName() + " at " + Main.calendar.getTime() + " .\n");
            }
        } catch (IOException ex) {
            Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
        } finally{
            if(writer != null){
                try {
                    writer.close();
                } catch (IOException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    

    @Override
    public void run() {
        isLandingTime = false;
        while(!this.status.equals("Flying")){
            try{
                if((departureTime.get(Calendar.HOUR_OF_DAY) == Main.calendar.get(Calendar.HOUR_OF_DAY)) && (departureTime.get(Calendar.MINUTE) == Main.calendar.get(Calendar.MINUTE)) && isTodayAWeekday(Main.calendar.get(Calendar.DAY_OF_WEEK))){
                //    this.isTakeOffTime = true;
                    this.status = "Flying";
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch(NullPointerException e){
                
            }    
        }
        writeReportFile(this, 0);
        //when status changes, refresh tables
        gui.fillJTables();
        while(!isLandingTime && !this.status.equals("Flight cancelled")){
            if((arrivalTime.get(Calendar.HOUR_OF_DAY) == Main.calendar.get(Calendar.HOUR_OF_DAY)) && (arrivalTime.get(Calendar.MINUTE) == Main.calendar.get(Calendar.MINUTE)) && isTodayAWeekday(Main.calendar.get(Calendar.DAY_OF_WEEK))){
                this.isLandingTime = true;
                this.status = "Waiting for Landing Permission";
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //when status changes, refresh tables
        gui.fillJTables();
        if(this.status.equals("Waiting for Landing Permission")){
            GUI.showMessage(this.flightNo + " is waiting for landing permission.");
        }
        
        while(this.status.equals("Waiting for Landing Permission")){
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //when status changes, refresh tables
        gui.fillJTables();
        
        if(this.status.equals("Landed")){
            writeReportFile(this, 1);
        }
        
        if(this.status.equals("Flight cancelled")){
            writeReportFile(this, 2);
        }
    }
}
