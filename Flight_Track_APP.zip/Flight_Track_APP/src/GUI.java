import java.awt.Font;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class GUI extends javax.swing.JFrame {

	Calendar settedCalendar;
    Calendar savedCalendar = Calendar.getInstance();
    boolean isTimeIncreaserActive = false;
    Thread timeIncreaser;
	
    public GUI() {
        initComponents();
        initProgram();
        fillJTables();
    }
    
    //This capitals and fligths have already added when program started.
    public void initProgram(){
        addCapital("Paris");
        addCapital("Lisbon");
        addCapital("Moscow");
        addCapital("Singapore");
        addCapital("London");
        ArrayList<String> weekdays = new ArrayList<String>();
        weekdays.add("Monday");
        weekdays.add("Tuesday");
        weekdays.add("Wednesday");
        weekdays.add("Thursday");
        weekdays.add("Friday");
        weekdays.add("Saturday");
        weekdays.add("Sunday");
        Main.flights.add(new Flight("123", "Turkish Airlines", "Boeing 787", inputCalendar("11:00"), inputCalendar("08:00"), weekdays, Main.capitals.get(0), Main.capitals.get(1), this));
        Main.flights.add(new Flight("1234", "Turkish Airlines", "Boeing 787", inputCalendar("15:00"), inputCalendar("09:00"), weekdays, Main.capitals.get(1), Main.capitals.get(2), this));
        Main.flights.add(new Flight("1235", "American Airlines", "Boeing 787", inputCalendar("23:00"), inputCalendar("18:00"), weekdays, Main.capitals.get(2), Main.capitals.get(3), this));
        Main.flights.add(new Flight("1236", "American Airlines", "Learjet 23", inputCalendar("17:00"), inputCalendar("12:00"), weekdays, Main.capitals.get(3), Main.capitals.get(4), this));
        Main.flights.add(new Flight("1231", "United Airlines", "Learjet 23", inputCalendar("11:00"), inputCalendar("07:00"), weekdays, Main.capitals.get(4), Main.capitals.get(3), this));
        Main.flights.add(new Flight("1232", "United Airlines", "Learjet 23", inputCalendar("11:00"), inputCalendar("06:00"), weekdays, Main.capitals.get(3), Main.capitals.get(2), this));
        Main.flights.add(new Flight("1233", "Qatar Airways", "Gulfstream G500", inputCalendar("09:00"), inputCalendar("05:00"), weekdays, Main.capitals.get(2), Main.capitals.get(1), this));
        Main.flights.add(new Flight("1238", "Qatar Airways", "Gulfstream G500", inputCalendar("11:00"), inputCalendar("08:00"), weekdays, Main.capitals.get(1), Main.capitals.get(0), this));
        Main.flights.add(new Flight("1239", "Emirates", "Gulfstream G500", inputCalendar("02:30"), inputCalendar("02:00"), weekdays, Main.capitals.get(0), Main.capitals.get(3), this));
        Main.flights.add(new Flight("1237", "Emirates", "Gulfstream G500", inputCalendar("11:00"), inputCalendar("08:00"), weekdays, Main.capitals.get(0), Main.capitals.get(2), this));
    }
    
    public void addCapital(String capitalName){
        Main.capitals.add(new Capital(capitalName));
        jComboBoxFromCapital.addItem(capitalName);
        jComboBoxToCapital.addItem(capitalName);
    }
    
    public boolean isInputTextCorrectForm(String text){
        
        try{
            int hours = Integer.parseInt(text.split(":")[0]);
            int minutes = Integer.parseInt(text.split(":")[1]);
            if((hours < 24 && hours >= 0) &&(minutes < 60 && minutes >= 0)){
                return true;
            }
        }catch(ArrayIndexOutOfBoundsException e){
            return false;
        }
        return false;
    }
    
    public int findIndexOfTheCapitalInCapitals(String capitalName){
        for(Capital c : Main.capitals){
            if(c.getName().equals(capitalName)){
                return Main.capitals.indexOf(c);
            }
        }
        return -1;
    }
    
    public static void showMessage(String msg){
        JLabel label = new JLabel(msg);
        label.setFont(new Font("Comic Sans MS", Font.PLAIN, 15));
        JOptionPane.showMessageDialog(null,label,"Message",JOptionPane.WARNING_MESSAGE);
    }
    
    //Create a Calendar object from input String
    public Calendar inputCalendar(String text){
        Calendar cal = new GregorianCalendar();
        if(isInputTextCorrectForm(text)){
            cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(text.split(":")[0]));
            cal.set(Calendar.MINUTE, Integer.parseInt(text.split(":")[1]));
            cal.set(Calendar.SECOND, 0);
            return cal;
        }
        showMessage("Please fill date areas corretly.");
        return null;
    }
    
    //take checked checkboxes and create an ArrayList from them
    public ArrayList<String> inputWeekdays(){
        ArrayList<String> weekdays = new ArrayList<String>();
        int i = 0;
        if(jCheckBoxMonday.isSelected()){
            weekdays.add("Monday");
            i++;
        }
        if(jCheckBoxTuesday.isSelected()){
            weekdays.add("Tuesday");
            i++;
        }
        if(jCheckBoxWednesday.isSelected()){
            weekdays.add("Wednesday");
            i++;
        }
        if(jCheckBoxThursday.isSelected()){
            weekdays.add("Thursday");
            i++;
        }
        if(jCheckBoxFriday.isSelected()){
            weekdays.add("Friday");
            i++;
        }
        if(jCheckBoxSaturday.isSelected()){
            weekdays.add("Saturday");
            i++;
        }
        if(jCheckBoxsunday.isSelected()){
            weekdays.add("Sunday");
            i++;
        }
        if(i != 0){
            return weekdays;
        }
        showMessage("Please fill the weekdays area.");
        return null;
    }
    
    public int findIndexOfFlightNumber(String flightNo){
        for(Flight f : Main.flights){
            if(f.getFlightNo().equals(flightNo)){
                return Main.flights.indexOf(f);
            }
        }
        showMessage("Flight not found.");
        return -1;
    }
    
    public void fillJTables(){
        jTableInformation.removeAll();
        jTableControlPanel.removeAll();
        DefaultTableModel model1 = (DefaultTableModel)jTableInformation.getModel();
        DefaultTableModel model2 = (DefaultTableModel)jTableControlPanel.getModel();
        model1.setRowCount(0);
        model2.setRowCount(0);
        Object rowData[] = new Object[9];
        for(int i = 0; i < Main.flights.size(); i++){
            rowData[0] = Main.flights.get(i).getFlightNo();
            rowData[1] = Main.flights.get(i).getAirlines();
            rowData[2] = Main.flights.get(i).getAircraftModel();
            rowData[3] = Main.flights.get(i).getFrom().getName();
            rowData[4] = Main.flights.get(i).getTo().getName();
            rowData[5] = String.valueOf(Main.flights.get(i).getDepartureTime().getTime()).split(" ")[3].substring(0, 5);
            rowData[6] = String.valueOf(Main.flights.get(i).getArrivalTime().getTime()).split(" ")[3].substring(0, 5);
            rowData[7] = Main.flights.get(i).getWeekdays();
            rowData[8] = Main.flights.get(i).getStatus();
            model1.addRow(rowData);
            model2.addRow(rowData);
        }
    }
    //Fill the input areas with the info seleceted on table
    public void showInfoTableOnFields(){
        int i = jTableInformation.getSelectedRow();
        TableModel model = jTableInformation.getModel();
        jTextFieldFlightNumber.setText(model.getValueAt(i, 0).toString());
        jTextFieldAirlines.setText(model.getValueAt(i, 1).toString());
        jTextFieldAircraftModel.setText(model.getValueAt(i, 2).toString());
        jComboBoxFromCapital.setSelectedItem(model.getValueAt(i, 3).toString());
        jComboBoxToCapital.setSelectedItem(model.getValueAt(i, 4).toString());
        jTextFieldDepartureTime.setText(model.getValueAt(i, 5).toString());
        jTextFieldArrivalTime.setText(model.getValueAt(i, 6).toString());
        ArrayList<String> weekdays = (ArrayList<String>)model.getValueAt(i, 7);
        if(weekdays.contains("Monday")){
            jCheckBoxMonday.setSelected(true);
        }else{
            jCheckBoxMonday.setSelected(false);
        }
        if(weekdays.contains("Tuesday")){
            jCheckBoxTuesday.setSelected(true);
        }else{
            jCheckBoxTuesday.setSelected(false);
        }
        if(weekdays.contains("Wednesday")){
            jCheckBoxWednesday.setSelected(true);
        }else{
            jCheckBoxWednesday.setSelected(false);
        }
        if(weekdays.contains("Thursday")){
            jCheckBoxThursday.setSelected(true);
        }else{
            jCheckBoxThursday.setSelected(false);
        }
        if(weekdays.contains("Friday")){
            jCheckBoxFriday.setSelected(true);
        }else{
            jCheckBoxFriday.setSelected(false);
        }
        if(weekdays.contains("Saturday")){
            jCheckBoxSaturday.setSelected(true);
        }else{
            jCheckBoxSaturday.setSelected(false);
        }
        if(weekdays.contains("Sunday")){
            jCheckBoxsunday.setSelected(true);
        }else{
            jCheckBoxsunday.setSelected(false);
        }
    }
    
    public void resetInfoFields(){
        jTextFieldFlightNumber.setText("");
        jTextFieldAirlines.setText("");
        jTextFieldAircraftModel.setText("");
        jComboBoxFromCapital.setSelectedItem("");
        jComboBoxToCapital.setSelectedItem("");
        jTextFieldDepartureTime.setText("");
        jTextFieldArrivalTime.setText("");
        jCheckBoxMonday.setSelected(false);
        jCheckBoxTuesday.setSelected(false);
        jCheckBoxWednesday.setSelected(false);
        jCheckBoxThursday.setSelected(false);
        jCheckBoxFriday.setSelected(false);
        jCheckBoxSaturday.setSelected(false);
        jCheckBoxsunday.setSelected(false);
        jTextFieldControlFlightNumber.setText("");
    }
    
    public void showFlightNumberOnControlMenu(){
        int i = jTableControlPanel.getSelectedRow();
        TableModel model = jTableControlPanel.getModel();
        jTextFieldControlFlightNumber.setText(model.getValueAt(i, 0).toString());
    }
    
    public void resetFlightNumberOnControlMenu(){
        jTextFieldControlFlightNumber.setText("");
    }
    //starts all the flight threads
    public void startFlights(){
        for(Flight f : Main.flights){
            f.start();
        }
    }
    
     public void copyCalendars(Calendar source, Calendar destination){
         destination.set(Calendar.DAY_OF_WEEK, source.get(Calendar.DAY_OF_WEEK));
         destination.set(Calendar.HOUR_OF_DAY, source.get(Calendar.HOUR_OF_DAY));
         destination.set(Calendar.MINUTE, source.get(Calendar.MINUTE));
         destination.set(Calendar.SECOND,0);
     }
     
     public void setFlightStatus(){
         for(Flight f : Main.flights){
             f.setStatus("Waiting to take off");
         }
     }

    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        FlightPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldFlightNumber = new javax.swing.JTextField();
        jTextFieldAirlines = new javax.swing.JTextField();
        jTextFieldAircraftModel = new javax.swing.JTextField();
        jTextFieldDepartureTime = new javax.swing.JTextField();
        jTextFieldArrivalTime = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jCheckBoxMonday = new javax.swing.JCheckBox();
        jCheckBoxFriday = new javax.swing.JCheckBox();
        jCheckBoxSaturday = new javax.swing.JCheckBox();
        jCheckBoxWednesday = new javax.swing.JCheckBox();
        jCheckBoxTuesday = new javax.swing.JCheckBox();
        jCheckBoxsunday = new javax.swing.JCheckBox();
        jCheckBoxThursday = new javax.swing.JCheckBox();
        jButtonAddFlight = new javax.swing.JButton();
        jButtonDeleteFlight = new javax.swing.JButton();
        jButtonUpdateFlight = new javax.swing.JButton();
        jTextFieldCapitalName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jButtonDeleteCapital = new javax.swing.JButton();
        jButtonAddCapital = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableInformation = new javax.swing.JTable();
        jComboBoxFromCapital = new javax.swing.JComboBox<>();
        jComboBoxToCapital = new javax.swing.JComboBox<>();
        ControlPanel = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabelShowSystemTime = new javax.swing.JLabel();
        jButtonStartTime = new javax.swing.JButton();
        jButtonPauseTime = new javax.swing.JButton();
        jButtonStopTime = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jComboBoxDays = new javax.swing.JComboBox<>();
        jTextFieldSystemTime = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jButtonSetDelay = new javax.swing.JButton();
        jButtonCancelFlight = new javax.swing.JButton();
        jButtonGivePermission = new javax.swing.JButton();
        jLabelShowFlightNumber = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableControlPanel = new javax.swing.JTable();
        jTextFieldControlFlightNumber = new javax.swing.JTextField();
        jButtonSetTime = new javax.swing.JButton();
        jButtonResume = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Flight Track App");
        setMinimumSize(new java.awt.Dimension(1294, 639));

        jTabbedPane1.setFont(new java.awt.Font("Comic Sans MS", 1, 15)); 
        jTabbedPane1.setMaximumSize(new java.awt.Dimension(1294, 639));
        jTabbedPane1.setMinimumSize(new java.awt.Dimension(1294, 639));

        FlightPanel.setFont(new java.awt.Font("Comic Sans MS", 1, 25));
        FlightPanel.setMaximumSize(new java.awt.Dimension(1294, 639));
        FlightPanel.setMinimumSize(new java.awt.Dimension(1294, 639));

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel1.setText("Flight Number:");

        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel2.setText("Airlines:");

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel3.setText("Aircraft Model;");

        jLabel4.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel4.setText("From:");

        jLabel5.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel5.setText("To:");

        jLabel6.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel6.setText("Departure Time (00:00):");

        jLabel7.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel7.setText("Arrival Time: (00:00):");

        jTextFieldFlightNumber.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jTextFieldFlightNumber.setText("12345");

        jTextFieldAirlines.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jTextFieldAirlines.setText("TurkishAirlines");

        jTextFieldAircraftModel.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jTextFieldAircraftModel.setText("Boeing");

        jTextFieldDepartureTime.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jTextFieldDepartureTime.setText("09:08");

        jTextFieldArrivalTime.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jTextFieldArrivalTime.setText("12:05");

        jLabel8.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel8.setText("Weekdays:");

        jCheckBoxMonday.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jCheckBoxMonday.setText("Monday");

        jCheckBoxFriday.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jCheckBoxFriday.setText("Friday");

        jCheckBoxSaturday.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jCheckBoxSaturday.setText("Saturday");

        jCheckBoxWednesday.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jCheckBoxWednesday.setText("Wednesday");

        jCheckBoxTuesday.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jCheckBoxTuesday.setText("Tuesday");

        jCheckBoxsunday.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jCheckBoxsunday.setText("Sunday");

        jCheckBoxThursday.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jCheckBoxThursday.setText("Thursday");

        jButtonAddFlight.setFont(new java.awt.Font("Comic Sans MS", 1, 20));
        jButtonAddFlight.setText("Add Flight");
        jButtonAddFlight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddFlightActionPerformed(evt);
            }
        });

        jButtonDeleteFlight.setFont(new java.awt.Font("Comic Sans MS", 1, 20));
        jButtonDeleteFlight.setText("Delete Flight");
        jButtonDeleteFlight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteFlightActionPerformed(evt);
            }
        });

        jButtonUpdateFlight.setFont(new java.awt.Font("Comic Sans MS", 1, 20));
        jButtonUpdateFlight.setText("Update Flight");
        jButtonUpdateFlight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpdateFlightActionPerformed(evt);
            }
        });

        jTextFieldCapitalName.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jTextFieldCapitalName.setText("Istanbul");

        jLabel9.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jLabel9.setText("Capital Name:");

        jButtonDeleteCapital.setFont(new java.awt.Font("Comic Sans MS", 1, 20));
        jButtonDeleteCapital.setText("Delete Capital");
        jButtonDeleteCapital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteCapitalActionPerformed(evt);
            }
        });

        jButtonAddCapital.setFont(new java.awt.Font("Comic Sans MS", 1, 20));
        jButtonAddCapital.setText("Add Capital");
        jButtonAddCapital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddCapitalActionPerformed(evt);
            }
        });

        jTableInformation.setFont(new java.awt.Font("Comic Sans MS", 0, 15));
        jTableInformation.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Flight Number", "Airlines", "Aircraft Model", "From", "To", "Departure Time", "Arrival Time", "Weekdays", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableInformation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableInformationMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableInformation);

        jComboBoxFromCapital.setFont(new java.awt.Font("Comic Sans MS", 0, 15));

        jComboBoxToCapital.setFont(new java.awt.Font("Comic Sans MS", 0, 15));

        javax.swing.GroupLayout FlightPanelLayout = new javax.swing.GroupLayout(FlightPanel);
        FlightPanel.setLayout(FlightPanelLayout);
        FlightPanelLayout.setHorizontalGroup(
            FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FlightPanelLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(FlightPanelLayout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jButtonUpdateFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(FlightPanelLayout.createSequentialGroup()
                            .addComponent(jButtonAddFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jButtonDeleteFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(FlightPanelLayout.createSequentialGroup()
                            .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(FlightPanelLayout.createSequentialGroup()
                                    .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(41, 41, 41))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, FlightPanelLayout.createSequentialGroup()
                                    .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                            .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTextFieldAircraftModel)
                                .addComponent(jTextFieldDepartureTime)
                                .addComponent(jTextFieldArrivalTime, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jTextFieldFlightNumber)
                                .addComponent(jComboBoxFromCapital, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBoxToCapital, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTextFieldAirlines, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(FlightPanelLayout.createSequentialGroup()
                            .addComponent(jCheckBoxMonday, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jCheckBoxThursday, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(FlightPanelLayout.createSequentialGroup()
                            .addComponent(jCheckBoxTuesday, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jCheckBoxFriday, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jCheckBoxsunday, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(FlightPanelLayout.createSequentialGroup()
                            .addComponent(jCheckBoxWednesday, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jCheckBoxSaturday, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FlightPanelLayout.createSequentialGroup()
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(41, 41, 41)
                            .addComponent(jTextFieldCapitalName, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FlightPanelLayout.createSequentialGroup()
                            .addComponent(jButtonAddCapital, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jButtonDeleteCapital, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 789, Short.MAX_VALUE)
                .addGap(28, 28, 28))
        );
        FlightPanelLayout.setVerticalGroup(
            FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FlightPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(FlightPanelLayout.createSequentialGroup()
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextFieldFlightNumber)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextFieldAirlines)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextFieldAircraftModel)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxFromCapital, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxToCapital, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldDepartureTime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldArrivalTime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jCheckBoxMonday, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBoxThursday, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jCheckBoxTuesday, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBoxFriday, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBoxsunday, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jCheckBoxWednesday, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBoxSaturday, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonAddFlight)
                            .addComponent(jButtonDeleteFlight))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonUpdateFlight)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldCapitalName, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FlightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonDeleteCapital)
                            .addComponent(jButtonAddCapital))))
                .addGap(41, 41, 41))
        );

        jTabbedPane1.addTab("Information", FlightPanel);

        ControlPanel.setFont(new java.awt.Font("Comic Sans MS", 1, 25)); // NOI18N
        ControlPanel.setMaximumSize(new java.awt.Dimension(1294, 639));
        ControlPanel.setMinimumSize(new java.awt.Dimension(1294, 639));

        jLabel10.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jLabel10.setText("Time:");

        jLabelShowSystemTime.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jLabelShowSystemTime.setText("Mon Jun 01 00:00 EET 2020");

        jButtonStartTime.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonStartTime.setText("Start");
        jButtonStartTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonStartTimeActionPerformed(evt);
            }
        });

        jButtonPauseTime.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonPauseTime.setText("Pause");
        jButtonPauseTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPauseTimeActionPerformed(evt);
            }
        });

        jButtonStopTime.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonStopTime.setText("Stop");
        jButtonStopTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonStopTimeActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jLabel12.setText("Set Time (00:00):");

        jComboBoxDays.setFont(new java.awt.Font("Comic Sans MS", 0, 15)); // NOI18N
        jComboBoxDays.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" }));

        jTextFieldSystemTime.setFont(new java.awt.Font("Comic Sans MS", 0, 15)); // NOI18N
        jTextFieldSystemTime.setText("12:05");

        jLabel13.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jLabel13.setText("Control Tower Menu:");

        jButtonSetDelay.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonSetDelay.setText("Set Delay");
        jButtonSetDelay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSetDelayActionPerformed(evt);
            }
        });

        jButtonCancelFlight.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonCancelFlight.setText("Cancel Flight");
        jButtonCancelFlight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelFlightActionPerformed(evt);
            }
        });

        jButtonGivePermission.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonGivePermission.setText("GivePermission");
        jButtonGivePermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGivePermissionActionPerformed(evt);
            }
        });

        jLabelShowFlightNumber.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jLabelShowFlightNumber.setText("Flight Number:");

        jTableControlPanel.setFont(new java.awt.Font("Comic Sans MS", 0, 15)); // NOI18N
        jTableControlPanel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Flight Number", "Airlines", "Aircraft Model", "From", "To", "Departure Time", "Arrival Time", "Weekdays", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableControlPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableControlPanelMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableControlPanel);

        jTextFieldControlFlightNumber.setEditable(false);
        jTextFieldControlFlightNumber.setFont(new java.awt.Font("Comic Sans MS", 2, 20)); // NOI18N

        jButtonSetTime.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonSetTime.setText("Set Time");
        jButtonSetTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSetTimeActionPerformed(evt);
            }
        });

        jButtonResume.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        jButtonResume.setText("Resume");
        jButtonResume.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonResumeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ControlPanelLayout = new javax.swing.GroupLayout(ControlPanel);
        ControlPanel.setLayout(ControlPanelLayout);
        ControlPanelLayout.setHorizontalGroup(
            ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ControlPanelLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(ControlPanelLayout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelShowSystemTime, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(ControlPanelLayout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBoxDays, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldSystemTime))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ControlPanelLayout.createSequentialGroup()
                        .addComponent(jButtonStartTime, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonPauseTime, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonResume, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonSetTime)
                    .addComponent(jButtonStopTime, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(ControlPanelLayout.createSequentialGroup()
                        .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelShowFlightNumber, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE)
                            .addComponent(jButtonSetDelay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldControlFlightNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(ControlPanelLayout.createSequentialGroup()
                                .addComponent(jButtonCancelFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButtonGivePermission)))
                        .addGap(15, 15, 15)))
                .addContainerGap(19, Short.MAX_VALUE))
            .addComponent(jScrollPane2)
        );
        ControlPanelLayout.setVerticalGroup(
            ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ControlPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ControlPanelLayout.createSequentialGroup()
                        .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldSystemTime)
                            .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel12)
                                .addComponent(jComboBoxDays, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButtonSetTime)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabelShowSystemTime))
                        .addGap(9, 9, 9)
                        .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonStartTime)
                            .addComponent(jButtonPauseTime)
                            .addComponent(jButtonStopTime)
                            .addComponent(jButtonResume)
                            .addComponent(jButtonSetDelay)
                            .addComponent(jButtonCancelFlight)
                            .addComponent(jButtonGivePermission)))
                    .addGroup(ControlPanelLayout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ControlPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelShowFlightNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldControlFlightNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115))
        );

        jTabbedPane1.addTab("Control", ControlPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }

    private void jButtonGivePermissionActionPerformed(java.awt.event.ActionEvent evt) {
        String flightNo = jTextFieldControlFlightNumber.getText();
        try{
            Main.flights.get(findIndexOfFlightNumber(flightNo)).setStatus("Landed");
        }catch(IndexOutOfBoundsException e){
            
        }
    }

    private void jButtonAddCapitalActionPerformed(java.awt.event.ActionEvent evt) {
        String capitalName = jTextFieldCapitalName.getText();
        if(findIndexOfTheCapitalInCapitals(capitalName) == -1){
            addCapital(capitalName);
        }else{
            showMessage("Capital already exists.");
        }
    }

    private void jButtonDeleteCapitalActionPerformed(java.awt.event.ActionEvent evt) {
        String capitalName = jTextFieldCapitalName.getText();
        int index = findIndexOfTheCapitalInCapitals(capitalName);
        if(index != -1){
            Main.capitals.remove(index);
            showMessage(capitalName + " deleted.");
            jComboBoxFromCapital.removeItemAt(index);
            jComboBoxToCapital.removeItemAt(index);
        }else{
            showMessage(capitalName + " is not found.");
        }
    }

    private void jButtonAddFlightActionPerformed(java.awt.event.ActionEvent evt) {
        String flightNo = jTextFieldFlightNumber.getText();
        String airlines = jTextFieldAirlines.getText();
        String aircraftModel = jTextFieldAircraftModel.getText();
        Capital fromCapital = new Capital(jComboBoxFromCapital.getSelectedItem().toString());
        Capital toCapital = new Capital(jComboBoxToCapital.getSelectedItem().toString());
        Calendar departureTime = inputCalendar(jTextFieldDepartureTime.getText());
        Calendar arrivalTime = inputCalendar(jTextFieldArrivalTime.getText());
        ArrayList<String> weekdays = inputWeekdays();
        if(!fromCapital.getName().equals(toCapital.getName())){
            if(departureTime != null && arrivalTime != null){
                if(weekdays != null){
                    Main.flights.add(new Flight(flightNo, airlines, aircraftModel, arrivalTime, departureTime, inputWeekdays(), fromCapital, toCapital, this));
                    resetInfoFields();
                }
            }
        }else{
            showMessage("Takeoff Capital and Landing capital cannot be the same.");
        }
        fillJTables();
    }

    private void jButtonDeleteFlightActionPerformed(java.awt.event.ActionEvent evt) {
        String flightNo = jTextFieldFlightNumber.getText();
        int index = findIndexOfFlightNumber(flightNo);
        if(index != -1){
            Main.flights.remove(index);
        }
        fillJTables();
    }

    private void jTableInformationMouseClicked(java.awt.event.MouseEvent evt) {
        showInfoTableOnFields();
    }

    private void jButtonUpdateFlightActionPerformed(java.awt.event.ActionEvent evt) {
        jButtonDeleteFlightActionPerformed(evt);
        jButtonAddFlightActionPerformed(evt);
        resetInfoFields();
    }

    private void jTableControlPanelMouseClicked(java.awt.event.MouseEvent evt) {
        showFlightNumberOnControlMenu();
    }

    private void jButtonStartTimeActionPerformed(java.awt.event.ActionEvent evt) {
        fillJTables();
        try{
            if(!isTimeIncreaserActive){
                Main.calendar = settedCalendar;
                timeIncreaser = new Thread(new Runnable(){
                    public void run(){
                        isTimeIncreaserActive = true;
                        while(isTimeIncreaserActive){
                            Main.calendar.add(Calendar.MINUTE, 1);
                            jLabelShowSystemTime.setText(String.valueOf(Main.calendar.getTime()));
                            savedCalendar = Main.calendar;
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                });
                timeIncreaser.start();
                startFlights();
            }
        }catch(IllegalThreadStateException e){
            
        }
    }

    private void jButtonPauseTimeActionPerformed(java.awt.event.ActionEvent evt) {
        timeIncreaser.suspend();
    }

    private void jButtonStopTimeActionPerformed(java.awt.event.ActionEvent evt) {
        isTimeIncreaserActive = false;
        setFlightStatus();
    }

    private void jButtonSetTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSetTimeActionPerformed
        try{
            String time = jTextFieldSystemTime.getText();
            if(isInputTextCorrectForm(time)){
                settedCalendar = Calendar.getInstance();
                settedCalendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.split(":")[0]));
                settedCalendar.set(Calendar.MINUTE, Integer.parseInt(time.split(":")[1])-1);
                settedCalendar.set(Calendar.SECOND, 0);
                settedCalendar.set(Calendar.DAY_OF_WEEK, jComboBoxDays.getSelectedIndex());
                copyCalendars(settedCalendar, savedCalendar);
                copyCalendars(settedCalendar, Main.calendar);
            }else{
                showMessage("Please fill time area corrently.");
            }
        }catch(IndexOutOfBoundsException e){
            
        }
    }

    private void jButtonSetDelayActionPerformed(java.awt.event.ActionEvent evt) {
        String flightNo = jTextFieldControlFlightNumber.getText();
        Main.flights.get(findIndexOfFlightNumber(flightNo)).setStatus("Waiting for Landing Permission");
    }

    private void jButtonCancelFlightActionPerformed(java.awt.event.ActionEvent evt) {
        String flightNo = jTextFieldControlFlightNumber.getText();
        Main.flights.get(findIndexOfFlightNumber(flightNo)).setStatus("Flight cancelled");
    }

    private void jButtonResumeActionPerformed(java.awt.event.ActionEvent evt) {
        timeIncreaser.resume();
    }

    private javax.swing.JPanel ControlPanel;
    private javax.swing.JPanel FlightPanel;
    private javax.swing.JButton jButtonAddCapital;
    private javax.swing.JButton jButtonAddFlight;
    private javax.swing.JButton jButtonCancelFlight;
    private javax.swing.JButton jButtonDeleteCapital;
    private javax.swing.JButton jButtonDeleteFlight;
    private javax.swing.JButton jButtonGivePermission;
    private javax.swing.JButton jButtonPauseTime;
    private javax.swing.JButton jButtonResume;
    private javax.swing.JButton jButtonSetDelay;
    private javax.swing.JButton jButtonSetTime;
    private javax.swing.JButton jButtonStartTime;
    private javax.swing.JButton jButtonStopTime;
    private javax.swing.JButton jButtonUpdateFlight;
    private javax.swing.JCheckBox jCheckBoxFriday;
    private javax.swing.JCheckBox jCheckBoxMonday;
    private javax.swing.JCheckBox jCheckBoxSaturday;
    private javax.swing.JCheckBox jCheckBoxThursday;
    private javax.swing.JCheckBox jCheckBoxTuesday;
    private javax.swing.JCheckBox jCheckBoxWednesday;
    private javax.swing.JCheckBox jCheckBoxsunday;
    private javax.swing.JComboBox<String> jComboBoxDays;
    private javax.swing.JComboBox<String> jComboBoxFromCapital;
    private javax.swing.JComboBox<String> jComboBoxToCapital;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelShowFlightNumber;
    private javax.swing.JLabel jLabelShowSystemTime;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTableControlPanel;
    private javax.swing.JTable jTableInformation;
    private javax.swing.JTextField jTextFieldAircraftModel;
    private javax.swing.JTextField jTextFieldAirlines;
    private javax.swing.JTextField jTextFieldArrivalTime;
    private javax.swing.JTextField jTextFieldCapitalName;
    private javax.swing.JTextField jTextFieldControlFlightNumber;
    private javax.swing.JTextField jTextFieldDepartureTime;
    private javax.swing.JTextField jTextFieldFlightNumber;
    private javax.swing.JTextField jTextFieldSystemTime;
}
