public class Capital {
    
    private String name;
    private Tower tower;

    public Capital(String name) {
        this.name = name;
        this.tower = new Tower(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Tower getTower() {
        return tower;
    }

    public void setTower(Tower tower) {
        this.tower = tower;
    }
}
