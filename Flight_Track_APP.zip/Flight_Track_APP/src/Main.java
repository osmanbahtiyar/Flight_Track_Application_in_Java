import java.util.ArrayList;
import java.util.Calendar;

public class Main {

    protected static ArrayList<Flight> flights = new ArrayList<Flight>();
    protected static ArrayList<Capital> capitals = new ArrayList<Capital>();
    protected static Calendar calendar = Calendar.getInstance();
    
    public static void main(String[] args) {
        GUI gui = new GUI();
        gui.setVisible(true);
    }
    
}
